package com.example.medimate

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MedicineViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    val tvMedicine: TextView = itemView.findViewById(R.id.tvMedicine)
    val ivMedicine: ImageView = itemView.findViewById(R.id.ivMedicine)
}
