package com.example.medimate

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class DoctorViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    val ivDoctor: ImageView = itemView.findViewById(R.id.ivDoctor)
    val tvDoctorName: TextView = itemView.findViewById(R.id.tvDoctorName)
    val tvDoctorLevel: TextView = itemView.findViewById(R.id.tvDoctorLevel)
    val tvDoctorSpecialist: TextView = itemView.findViewById(R.id.tvDoctorSpecialist)
}
