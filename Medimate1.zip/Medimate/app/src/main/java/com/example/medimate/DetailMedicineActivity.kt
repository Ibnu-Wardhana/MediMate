package com.example.medimate

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.squareup.picasso.Picasso


class DetailMedicineActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_medicine)

        // Inisialisasi elemen tampilan
        val tvMedicineName: TextView = findViewById(R.id.tvMedicineName)
        val tvMedicineDesc: TextView = findViewById(R.id.tvMedicineDesc)
        val tvMedicineHowToUse: TextView = findViewById(R.id.tvMedicineHowToUse)
        val ivMedicineImg: ImageView = findViewById(R.id.ivMedicineImg)

        // Terima data yang dikirimkan melalui Intent
        val medicine: Medicine? = intent.getParcelableExtra("medicine")

        // Periksa apakah objek Medicine tidak null sebelum mengakses propertinya
        if (medicine != null) {
            // Set data ke elemen tampilan
            tvMedicineName.text = medicine.medicineName
            tvMedicineDesc.text = medicine.desc
            tvMedicineHowToUse.text = medicine.howToUse

            // Load gambar menggunakan Picasso
            Picasso.get()
                .load(medicine.imgUrl)
                .error(R.color.black)
                .into(ivMedicineImg)
        } else {
            // Objek medicine null, handle sesuai kebutuhan (misalnya, tampilkan pesan error)
            // ...
            Toast.makeText(this, "Data obat tidak valid", Toast.LENGTH_SHORT).show()
            finish() // Selesaikan aktivitas jika data tidak valid
        }
    }
}
