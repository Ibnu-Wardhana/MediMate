package com.example.medimate

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Doctor(
    val doctorName: String = "",
    val level: String = "",
    val specialist: String = "",
    val imgUrl: String = "" // Tambahkan imgUrl ke model
) : Parcelable
