package com.example.medimate

data class DataUsers(
var name : String? = null,
var email : String? = null,
var nik : String? = null,
var phone : String? = null,

)
