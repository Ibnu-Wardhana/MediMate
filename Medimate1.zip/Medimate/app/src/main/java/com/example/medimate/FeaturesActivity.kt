package com.example.medimate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.auth.User


class FeaturesActivity : AppCompatActivity() {
    private lateinit var tvDisplayName: TextView
    private lateinit var databaseReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_features)

        val ivBooking: ImageView = findViewById(R.id.ivBooking)
        val ivMedicine: ImageView = findViewById(R.id.ivMedicine)
        val ivDoctor: ImageView = findViewById(R.id.ivDoctor)
        val ivHospital: ImageView = findViewById(R.id.ivHospital)
        val bDirection: Button = findViewById(R.id.bDirection)

        ivBooking.setOnClickListener {
            val intent = Intent(this, ScheduleActivity::class.java)
            startActivity(intent)
        }

        ivMedicine.setOnClickListener {
            val intent = Intent(this, MedicineActivity::class.java)
            startActivity(intent)
        }

        ivDoctor.setOnClickListener {
            val intent = Intent(this, DoctorActivity::class.java)
            startActivity(intent)
        }
        ivHospital.setOnClickListener {
            val intent = Intent(this, HospitalActivity::class.java)
            startActivity(intent)
        }
        bDirection.setOnClickListener {
            val intent = Intent(this, MapActivity::class.java)
            startActivity(intent)
        }

        // Inisialisasi TextView
        tvDisplayName = findViewById(R.id.tvDisplayName)

        // Dapatkan referensi database Firebase
        auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser
        val userUid = currentUser?.uid

        userUid?.let {
            databaseReference = FirebaseDatabase.getInstance().getReference("users").child(it)
            databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.exists()) {
                        val name = dataSnapshot.child("name").value.toString()

                        tvDisplayName.text = "Hai! $name"
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Handle failure to retrieve data
                    Log.e("FeaturesActivity", "Error: ${databaseError.message}")
                }
            })
        } ?: run {
            // Handle the case where userUid is null (user not logged in)
            Log.e("FeaturesActivity", "User not logged in.")
            // You might want to redirect the user to the login screen here
        }
    }
}