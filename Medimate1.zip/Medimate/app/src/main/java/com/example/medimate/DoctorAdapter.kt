package com.example.medimate

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.medimate.R
import com.squareup.picasso.Picasso

class DoctorAdapter(private val context: Context) :
    RecyclerView.Adapter<DoctorViewHolder>() {

    private var doctorList: List<Doctor> = emptyList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DoctorViewHolder {
        val view =
            LayoutInflater.from(context).inflate(R.layout.list_doctor, parent, false)
        return DoctorViewHolder(view)
    }

    override fun onBindViewHolder(holder: DoctorViewHolder, position: Int) {
        val currentDoctor = doctorList[position]

        // Set data ke elemen tampilan
        holder.tvDoctorName.text = currentDoctor.doctorName
        holder.tvDoctorLevel.text = currentDoctor.level
        holder.tvDoctorSpecialist.text = currentDoctor.specialist

        // Load gambar menggunakan Picasso
        Picasso.get()
            .load(currentDoctor.imgUrl)
            .error(R.color.black)
            .into(holder.ivDoctor)
    }

    override fun getItemCount(): Int {
        return doctorList.size
    }

    fun setDoctorList(doctorList: List<Doctor>) {
        this.doctorList = doctorList
        notifyDataSetChanged()
    }
}
