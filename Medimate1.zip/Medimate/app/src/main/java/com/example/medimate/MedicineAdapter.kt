package com.example.medimate

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.firebase.ui.database.FirebaseRecyclerAdapter
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.squareup.picasso.Picasso

class MedicineAdapter(options: FirebaseRecyclerOptions<Medicine>, private val context: Context) :
    FirebaseRecyclerAdapter<Medicine, MedicineViewHolder>(options) {

    private var itemClickListener: OnItemClickListener? = null

    interface OnItemClickListener {
        fun onItemClick(medicine: Medicine)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.itemClickListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MedicineViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_medicine, parent, false)
        return MedicineViewHolder(view)
    }

    override fun onBindViewHolder(holder: MedicineViewHolder, position: Int, model: Medicine) {
        holder.tvMedicine.text = model.medicineName

        // Load image using Picasso library, and set black background if imgUrl is not valid
        Picasso.get()
            .load(model.imgUrl)
            .error(R.color.black) // Set black color if imgUrl is not valid
            .into(holder.ivMedicine)

        // Handle item click
        holder.itemView.setOnClickListener {
            itemClickListener?.onItemClick(model)
        }
    }
}
