package com.example.medimate

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.database.FirebaseDatabase

class MedicineActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var medicineAdapter: MedicineAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_medicine)

        recyclerView = findViewById(R.id.recyclerViewMedicine)

        // Set up FirebaseRecyclerOptions to configure FirebaseRecyclerAdapter
        val options = FirebaseRecyclerOptions.Builder<Medicine>()
            .setQuery(FirebaseDatabase.getInstance().getReference("medicine"), Medicine::class.java)
            .build()

        // Initialize MedicineAdapter
        medicineAdapter = MedicineAdapter(options, this)

        // Set listener untuk menangani klik pada item RecyclerView
        medicineAdapter.setOnItemClickListener(object : MedicineAdapter.OnItemClickListener {
            override fun onItemClick(medicine: Medicine) {
                // Buka DetailMedicineActivity dengan membawa data yang sesuai
                val intent = Intent(this@MedicineActivity, DetailMedicineActivity::class.java)
                intent.putExtra("medicine", medicine)
                startActivity(intent)
            }
        })

        // Set RecyclerView adapter
        recyclerView.adapter = medicineAdapter

        // Set RecyclerView layoutManager
        recyclerView.layoutManager = LinearLayoutManager(this)
    }

    override fun onStart() {
        super.onStart()
        medicineAdapter.startListening()
    }

    override fun onStop() {
        super.onStop()
        medicineAdapter.stopListening()
    }
}
