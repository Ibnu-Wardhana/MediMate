package com.example.medimate

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class DoctorActivity : AppCompatActivity() {

    private lateinit var recyclerViewDoctor: RecyclerView
    private lateinit var doctorAdapter: DoctorAdapter
    private lateinit var databaseReference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor)

        recyclerViewDoctor = findViewById(R.id.recyclerViewDoctor)

        // Inisialisasi RecyclerView
        doctorAdapter = DoctorAdapter(this)
        recyclerViewDoctor.adapter = doctorAdapter
        recyclerViewDoctor.layoutManager = GridLayoutManager(this,2)

        // Inisialisasi Firebase Database
        databaseReference = FirebaseDatabase.getInstance().getReference("doctor")

        // Mendapatkan daftar dokter dari Firebase
        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val doctors = mutableListOf<Doctor>()
                for (snapshot in dataSnapshot.children) {
                    val doctor = snapshot.getValue(Doctor::class.java)
                    doctor?.let { doctors.add(it) }
                }
                doctorAdapter.setDoctorList(doctors)
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle error
            }
        })
    }
}
